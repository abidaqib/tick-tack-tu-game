﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TickTaTowApplication
{
    public partial class GameForm : Form
    {
        public GameForm()
        {
            InitializeComponent();
        }
        int a = 0, b = 0, c = 0, d = 0, e = 0, f = 0, j = 0, h = 0, i = 0, count = 0 ;

        private void button8_Click(object sender, EventArgs e)
        {
            count++;
            if (count % 2 == 0)
            {
                h = 2;
                button8.Text = "O";
            }
            else
            {
                button8.Text = "X";
                h = 1;
            }
            button8.Enabled = false;
            logic();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            count++;
            if (count % 2 == 0)
            {
                i = 2;
                button9.Text = "O";
            }
            else
            {
                button9.Text = "X";
                i = 1;
            }
            button9.Enabled = false;
            logic();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            count++;
            if (count % 2 == 0)
            {
                j = 2;
                button7.Text = "O";
            }
            else
            {
                button7.Text = "X";
                j = 1;
            }
            button7.Enabled = false;
            logic();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            count++;
            if (count % 2 == 0)
            {
                f = 2;
                button6.Text = "O";
            }
            else
            {
                button6.Text = "X";
                f = 1;
            }
            button6.Enabled = false;
            logic();
        }

        private void button5_Click(object sender, EventArgs e1)
        {
            count++;
            if (count % 2 == 0)
            {
                e = 2;
                button5.Text = "O";
            }
            else
            {
                button5.Text = "X";
                e = 1;
            }
            button5.Enabled = false;
            logic();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            count++;
            if (count % 2 == 0)
            {
                d = 2;
                button4.Text = "O";
            }
            else
            {
                button4.Text = "X";
                d = 1;
            }
            button4.Enabled = false;
            logic();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            count++;
            if (count % 2 == 0)
            {
                c = 2;
                button3.Text = "O";
            }
            else
            {
                button3.Text = "X";
                c = 1;
            }
            button3.Enabled = false;
            logic();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            count++;
            if (count % 2 == 0)
            {
                b = 2;
                button2.Text = "O";
            }
            else
            {
                button2.Text = "X";
                b = 1;
               
            }
            button2.Enabled = false;
            logic();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            count++;
            if(count%2==0)
            {
                a = 2;
                button1.Text = "O";
            }
            else
            {
                button1.Text = "X";
                a = 1;
               
            }
            button1.Enabled = false;
            logic();
        }

        private void GameForm_Load(object sender, EventArgs e)
        {
            
        }
         private void textOff()
        {
            button1.Text = "";
            button2.Text = "";
            button3.Text = "";
            button4.Text = "";
            button5.Text = "";
            button6.Text = "";
            button7.Text = "";
            button8.Text = "";
            button9.Text = "";
            button1.Enabled = true;
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button6.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;

            a = 0; b = 0; c = 0; d = 0; e = 0; f = 0; j = 0; h = 0; i = 0; count = 0;
        }

        private void logic()
        {
            {
                if (a == b && b == c && a != 0)
                {
                    if (a == 1)
                    {
                        MessageBox.Show("X win");
                    }
                    else
                    {
                        MessageBox.Show("O win");
                    }
                    textOff();
                    
                }
                else if (d == e && e == f && d != 0)
                {
                    if (b == 1)
                    {
                        MessageBox.Show("X win");
                        
                    }
                    else
                    {
                        MessageBox.Show("O win");
                    }
                    //MessageBox.Show("Win");
                    textOff();
                }
                else if (j == h && h == i && j != 0)
                {
                    if (j == 1)
                    {
                        MessageBox.Show("X win");
                    }
                    else
                    {
                        MessageBox.Show("O win");
                    }
                    //MessageBox.Show("Win");
                    textOff();
                }
                else if (a == e && e == i && a != 0)
                {
                    if (a == 1)
                    {
                        MessageBox.Show("X win");
                    }
                    else
                    {
                        MessageBox.Show("O win");
                    }
                    //MessageBox.Show("Win");
                    textOff();
                }
                else if (c == e && e == j && c != 0)
                {
                    if (c == 1)
                    {
                        MessageBox.Show("X win");
                    }
                    else
                    {
                        MessageBox.Show("O win");
                    }
                    //MessageBox.Show("Win");
                    textOff();
                }
                else if (b == e && e == h && b != 0)
                {
                    if (b == 1)
                    {
                        MessageBox.Show("X win");
                    }
                    else
                    {
                        MessageBox.Show("O win");
                    }
                    //MessageBox.Show("Win");
                    textOff();
                }
                else if (a == d && d == j && a != 0)
                {
                    if (a == 1)
                    {
                        MessageBox.Show("X win");
                    }
                    else
                    {
                        MessageBox.Show("O win");
                    }
                    //MessageBox.Show("Win");
                    textOff();
                }
                else if (c == f && f == i && c != 0)
                {
                    if (c == 1)
                    {
                        MessageBox.Show("X win");
                    }
                    else
                    {
                        MessageBox.Show("O win");
                    }
                    //MessageBox.Show("Win");
                    textOff();
                }

                else if (count == 9)
                {

                    MessageBox.Show("Draw");
                    textOff();
                }
            }
        }
    }
}
